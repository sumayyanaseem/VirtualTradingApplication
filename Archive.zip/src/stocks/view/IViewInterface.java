package stocks.view;

public interface IViewInterface {

  /**
   * displays the given message.
   */
  void displayMessage(String s);

}
