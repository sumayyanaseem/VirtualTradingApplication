                                            WORKING FEATURES
**********************************************************************************************************************************
1) Allows user to create one or more portfolios
2) Allows the user to input stocks info using text based UI to create a portfolio.
3) Allows the user to load a csv file consisting of stocks info to create a portfolio.
   ( one file per one portfolio. Multiple portfolio info in single file is not supported )
4) Allows user to add stocks to the portfolio ( only buy option is supported )
5) Portfolio once created after adding stocks, User cant modify that portfolio.
6) Allows user to add only stocks of 25 companies supported by our application.
7) Allows user to view the composition of his portfolios as of the date that he wishes to view.
8) Allows user to view the total value of any of his portfolios that he wishes to view.
9) The csv files can be saved and retrieved and are human-readable
10) Allows user to create a csv file outside of the program using a text editor and our program will load it in.
11) Our program doesn't crash when user enters invalid inputs. Validations are done at every point and error is displayed to user.
Our prgraam keeps asking user to enter inputs until he enters a valid input format.