/**
 * The test class for Integration testing of Controller and Model.
 */
public class ControllerAndModelIntegrationTest {
}
