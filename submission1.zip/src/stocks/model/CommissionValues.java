package stocks.model;

public enum CommissionValues {
  /*  2000(2),
    2005("5"),
  2010("10"),
  2015("12"),
  2020("15"),
  2025("17");
  public final String label;

  CommissionValues(String label) {
    this.label = label;
  }

  public String getValue() {
    return label;
  }*/

}
